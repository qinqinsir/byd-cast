package com.pvg.caster

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class CaptureService : Service() {
    private lateinit var webrtc: WebRtcSender
    private lateinit var signaling: SignalingServer

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification("投屏已启动，等待车机连接…"))

        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data")

        webrtc = WebRtcSender(this)
        webrtc.initWithMediaProjection(resultCode, data)

        signaling = SignalingServer(8888) { msg -> webrtc.onSignalingMessage(msg) }
        signaling.start()

        webrtc.onLocalSdp = { sdpJson -> signaling.broadcast(sdpJson) }
        webrtc.onLocalIce = { iceJson -> signaling.broadcast(iceJson) }
        webrtc.start()

        return START_STICKY
    }

    override fun onDestroy() {
        try { webrtc.release() } catch (_: Exception) {}
        try { signaling.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(content: String): Notification {
        val channelId = "cast_channel"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Casting", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("投屏助手")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .build()
    }
}
