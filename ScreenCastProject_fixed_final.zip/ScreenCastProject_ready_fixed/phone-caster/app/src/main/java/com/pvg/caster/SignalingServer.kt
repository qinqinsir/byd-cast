package com.pvg.caster

import fi.iki.elonen.NanoWSD
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD.WebSocketFrame
import java.io.IOException
import java.util.Collections

class SignalingServer(private val port: Int, private val onMessage: (String) -> Unit) {

    private var server: NanoSignalingWSD? = null
    private val sockets = Collections.synchronizedSet(mutableSetOf<NanoSocket>())

    fun start() {
        if (server != null) return
        server = NanoSignalingWSD(port).also {
            it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        }
    }

    fun stop() {
        try { server?.stop() } catch (_: Exception) {}
        server = null
        val copy = synchronized(sockets) { sockets.toList() }
        copy.forEach { runCatching { it.close(WebSocketFrame.CloseCode.NormalClosure, "bye", false) } }
        sockets.clear()
    }

    fun broadcast(text: String) {
        val copy = synchronized(sockets) { sockets.toList() }
        copy.forEach { runCatching { it.send(text) } }
    }

    private inner class NanoSignalingWSD(port: Int) : NanoWSD(port) {
        override fun openWebSocket(handshake: NanoHTTPD.IHTTPSession?): WebSocket {
            val s = NanoSocket(handshake)
            sockets += s
            return s
        }
    }

    private inner class NanoSocket(handshakeRequest: NanoHTTPD.IHTTPSession?) : WebSocket(handshakeRequest) {
    override fun onOpen() { }
    override fun onMessage(message: WebSocketFrame) {
        val text = message.textPayload ?: return
        onMessage(text)
        broadcast(text)
    }
    override fun onClose(code: WebSocketFrame.CloseCode, reason: String?, initiatedByRemote: Boolean) {
        sockets -= this
    }
    override fun onPong(pong: WebSocketFrame) { }
    override fun onException(exception: IOException) {
        sockets -= this
    }
}
        override fun onClose(code: WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) {
            sockets -= this
        }
        override fun onException(exception: java.lang.Exception?) {
            sockets -= this
        }
        override fun onPong(pong: WebSocketFrame?) { }
    }
}
