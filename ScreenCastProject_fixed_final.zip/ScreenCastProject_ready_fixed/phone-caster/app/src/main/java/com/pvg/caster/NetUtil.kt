package com.pvg.caster

import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter

object NetUtil {
    fun getLocalIp(ctx: Context): String {
        return try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            Formatter.formatIpAddress(wm.connectionInfo.ipAddress)
        } catch (e: Exception) {
            "0.0.0.0"
        }
    }
}
