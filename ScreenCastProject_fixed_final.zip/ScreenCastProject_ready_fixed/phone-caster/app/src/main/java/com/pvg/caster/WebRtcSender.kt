package com.pvg.caster

import android.content.Context
import android.content.Intent
import org.webrtc.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import org.json.JSONObject
import android.media.projection.MediaProjection

class WebRtcSender(private val ctx: Context) {
        private fun sdpToJson(desc: SessionDescription): String {
            val o = JSONObject()
            o.put("type", desc.type.canonicalForm())
            o.put("sdp", desc.description)
            return o.toString()
        }
        private fun sdpFromJson(s: String): SessionDescription {
            val o = JSONObject(s)
            val type = SessionDescription.Type.fromCanonicalForm(o.getString("type"))
            val sdp = o.getString("sdp")
            return SessionDescription(type, sdp)
        }

    private lateinit var factory: PeerConnectionFactory
    private var pc: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var videoCapturer: VideoCapturer? = null

    var onLocalSdp: ((String) -> Unit)? = null
    var onLocalIce: ((String) -> Unit)? = null

    fun initWithMediaProjection(resultCode: Int, data: Intent?) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions()
        )
        val egl = EglBase.create()
        val options = PeerConnectionFactory.Options()
        val encoderFactory = DefaultVideoEncoderFactory(egl.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(egl.eglBaseContext)
        factory = PeerConnectionFactory.builder()
            .setOptions(options)
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        // Screen capture
        videoCapturer = ScreenCapturerAndroid(data, object: MediaProjection.Callback(){})
        val surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", egl.eglBaseContext)
        videoSource = factory.createVideoSource(false)
        (videoCapturer as ScreenCapturerAndroid).initialize(surfaceTextureHelper, ctx, videoSource!!.capturerObserver)

        // Audio
        audioSource = factory.createAudioSource(MediaConstraints())

        val rtcConfig = PeerConnection.RTCConfiguration(mutableListOf()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        pc = factory.createPeerConnection(rtcConfig, object: PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val ice = WsMsg("ice", ice = IceMsg(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp))
                onLocalIce?.invoke(Json.encodeToString(ice))
            }
            override fun onTrack(transceiver: RtpTransceiver?) { }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {}
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {}
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
            override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
        })

        val videoTrack = factory.createVideoTrack("video", videoSource)
        val audioTrack = factory.createAudioTrack("audio", audioSource)

        pc?.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO).sender.setTrack(videoTrack, true)
        pc?.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO).sender.setTrack(audioTrack, true)
    }

    fun start() {
        (videoCapturer as? ScreenCapturerAndroid)?.startCapture(1280, 720, 30)
        pc?.createOffer(object: SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc?.setLocalDescription(object: SdpObserver {
                    override fun onSetSuccess() {}
                    override fun onSetFailure(p0: String?) {}
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, desc)
                val msg = WsMsg("offer", sdp = sdpToJson(desc))
                onLocalSdp?.invoke(Json.encodeToString(msg))
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(p0: String?) {}
            override fun onSetFailure(p0: String?) {}
        }, MediaConstraints())
    }

    fun onSignalingMessage(json: String) {
        try {
            val msg = Json.decodeFromString<WsMsg>(json)
            when (msg.type) {
                "answer" -> {
                    val desc = sdpFromJson(msg.sdp!!)
                    pc?.setRemoteDescription(object: SdpObserver {
                        override fun onSetSuccess() {}
                        override fun onSetFailure(p0: String?) {}
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onCreateFailure(p0: String?) {}
                    }, desc)
                }
                "ice" -> {
                    val ice = msg.ice!!
                    pc?.addIceCandidate(IceCandidate(ice.sdpMid, ice.sdpMLineIndex, ice.candidate))
                }
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try { (videoCapturer as? ScreenCapturerAndroid)?.stopCapture() } catch (_: Exception) {}
        pc?.close()
        videoSource?.dispose()
        audioSource?.dispose()
    }
}
