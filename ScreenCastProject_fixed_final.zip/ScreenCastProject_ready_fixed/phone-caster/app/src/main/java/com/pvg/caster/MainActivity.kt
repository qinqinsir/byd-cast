package com.pvg.caster

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val mediaProjectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    private val requestCapture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", res.resultCode)
                putExtra("data", res.data)
            }
            ContextCompat.startForegroundService(this, intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)
        val tv = findViewById<TextView>(R.id.tvAddr)

        val ws = "ws://${NetUtil.getLocalIp(this)}:8888/ws"
        tv.text = ws

        btnStart.setOnClickListener {
            val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
            requestCapture.launch(captureIntent)
        }
        btnStop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
        }
    }
}
