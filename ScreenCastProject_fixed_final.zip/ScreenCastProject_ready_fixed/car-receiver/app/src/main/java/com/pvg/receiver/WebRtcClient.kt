package com.pvg.receiver

import android.content.Context
import kotlinx.coroutines.*
import io.ktor.client.*
import io.ktor.client.plugins.websocket.*
import io.ktor.websocket.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import org.json.JSONObject
import org.webrtc.*

class WebRtcClient(
    private val ctx: Context,
    private val wsUrl: String,
    private val renderer: SurfaceViewRenderer
) {
          private fun sdpToJson(desc: SessionDescription): String {
              val o = JSONObject()
              o.put("type", desc.type.canonicalForm())
              o.put("sdp", desc.description)
              return o.toString()
          }
          private fun sdpFromJson(s: String): SessionDescription {
              val o = JSONObject(s)
              val type = SessionDescription.Type.fromCanonicalForm(o.getString("type"))
              val sdp = o.getString("sdp")
              return SessionDescription(type, sdp)
          }

    private val client = HttpClient { install(WebSockets) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var factory: PeerConnectionFactory
    private var pc: PeerConnection? = null
    private lateinit var egl: EglBase

    fun connect() {
        initRtc()
        scope.launch {
            try {
                client.webSocket(wsUrl) {
                    for (frame in incoming) {
                        if (frame is Frame.Text) {
                            val text = frame.readText()
                            onWsMessage(text, this)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    private suspend fun onWsMessage(text: String, session: DefaultClientWebSocketSession) {
        try {
            val msg = Json.decodeFromString<WsMsg>(text)
            when (msg.type) {
                "offer" -> {
                    val desc = sdpFromJson(msg.sdp!!)
                    withContext(Dispatchers.Main) {
                        pc?.setRemoteDescription(object: SdpObserver {
                            override fun onSetSuccess() {
                                pc?.createAnswer(object: SdpObserver {
                                    override fun onCreateSuccess(answer: SessionDescription) {
                                        pc?.setLocalDescription(object: SdpObserver {
                                            override fun onSetSuccess() {}
                                            override fun onSetFailure(p0: String?) {}
                                            override fun onCreateSuccess(p0: SessionDescription?) {}
                                            override fun onCreateFailure(p0: String?) {}
                                        }, answer)
                                        val res = WsMsg("answer", sdp = sdpToJson(answer))
                                        scope.launch { session.send(Json.encodeToString(res)) }
                                    }
                                    override fun onSetSuccess() {}
                                    override fun onCreateFailure(p0: String?) {}
                                    override fun onSetFailure(p0: String?) {}
                                }, MediaConstraints())
                            }
                            override fun onSetFailure(p0: String?) {}
                            override fun onCreateSuccess(p0: SessionDescription?) {}
                            override fun onCreateFailure(p0: String?) {}
                        }, desc)
                    }
                }
                "ice" -> {
                    val ice = msg.ice!!
                    pc?.addIceCandidate(IceCandidate(ice.sdpMid, ice.sdpMLineIndex, ice.candidate))
                }
            }
        } catch (_: Exception) {}
    }

    private fun initRtc() {
        egl = EglBase.create()
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions()
        )
        val encoderFactory = DefaultVideoEncoderFactory(egl.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(egl.eglBaseContext)
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        renderer.init(egl.eglBaseContext, null)
        renderer.setEnableHardwareScaler(true)
        renderer.setMirror(false)

        val rtcConfig = PeerConnection.RTCConfiguration(mutableListOf()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        pc = factory.createPeerConnection(rtcConfig, object: PeerConnection.Observer {
            override fun onTrack(transceiver: RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.addSink(renderer)
            }
            override fun onIceCandidate(candidate: IceCandidate) {}
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {}
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {}
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
            override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
        })

        pc?.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO)
        pc?.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO)
    }

    fun release() {
        pc?.close()
        renderer.release()
    }
}
