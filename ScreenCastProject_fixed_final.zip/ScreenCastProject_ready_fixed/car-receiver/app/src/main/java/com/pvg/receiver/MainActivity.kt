package com.pvg.receiver

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import org.webrtc.SurfaceViewRenderer

class MainActivity : AppCompatActivity() {
    private lateinit var client: WebRtcClient
    private lateinit var renderer: SurfaceViewRenderer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        renderer = SurfaceViewRenderer(this)
        findViewById<android.widget.FrameLayout>(R.id.videoContainer).addView(renderer)

        val etWs = findViewById<EditText>(R.id.etWs)
        findViewById<Button>(R.id.btnConnect).setOnClickListener {
            val ws = etWs.text.toString().trim()
            client = WebRtcClient(this, ws, renderer)
            client.connect()
        }
    }

    override fun onDestroy() {
        try { client.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
