package com.pvg.receiver
import kotlinx.serialization.Serializable
@Serializable data class WsMsg(val type: String, val sdp: String? = null, val ice: IceMsg? = null)
@Serializable data class IceMsg(val sdpMid: String?, val sdpMLineIndex: Int, val candidate: String)
